const commands = require('./lib/commands');
const helper = require('./lib/helper')
/*
 * Handler de entrada dos comandos
 */
exports.handler = function(event, context, callback) {
    console.log("EVENTO:", event);
    var ev = helper.getQueryParameters(event.body);
    var action = processCommands(ev);
    callback(null, action);
}

/**
 * Process Commands
 *
 * @param {object} event AWS Lambda Event
 * @return {object} Request Promise
 */
function processCommands(event) {
    
    console.log(event);

    if (event && event.command) {
        console.log(event.command, event.text);
        var command = decodeURIComponent(event.command.trim()).replace("/", "");
        console.log(command, commands[command]);        
        return commands[command]("");
    }

    return commands.error('Event not specified');
}